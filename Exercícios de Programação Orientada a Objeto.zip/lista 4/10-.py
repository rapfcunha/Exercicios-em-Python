"""Ex - 10 """

class BombaCombustivel:
    def __init__ (self, tipoCombustivel, valorLitro, quantidadeCombustivel):
        
      self.tipoCombustivel = tipoCombustivel
      self.valorLitro = valorLitro
      self.quantidadeCombustivel = quantidadeCombustivel
    
    def alterarValor (self, valorLitro): 
        self.valorLitro = valorLitro
        
    def alterarCombustivel (self, tipoCombustivel): 
        self.tipoCombustivel = tipoCombustivel
        
    def alterarQuantidadeCombustivel (self, quantidadeCombustivel): 
        self.quantidadeCombustivel = quantidadeCombustivel
    
    def abastecerPorValor (self, valor): 
        temp = valor / self.valorLitro
        self.alterarQuantidadeCombustivel (self.quantidadeCombustivel - temp) 
        return temp
    def abastecerPorLitro (self, qtd):
      temp2 =  qtd * self.valorLitro
        self.alterarQuantidadeCombustivel (self.quantidadeCombustivel -	qtd) 
        return temp2
        
a1 = BombaCombustivel ("Gasolina", 5, 500) 
print (a1.abastecerPorValor (150))
print (a1.quantidadeCombustivel)
print (a1.abastecerPorLitro (30)) 
print (a1.quantidadeCombustivel)